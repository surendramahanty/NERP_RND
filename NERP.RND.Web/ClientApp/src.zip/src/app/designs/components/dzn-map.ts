import { Component, Input, SimpleChanges, OnInit, OnChanges } from '@angular/core';
import { Design } from '../models/design';
import { AppConfig } from '../../app.config';
import { BomHelper } from '../services/bom.helper';
import { GMapsHelper } from '../../common/geo/googleMapsHelper';
import { GeoHelper } from '../../common/geo/geoHelper';
import { EntitiesHelper } from '../services/entities.helper';
import { GeoNode, Segment } from '../../common/geo/geoNode';
import { MapEntitiesHelper } from '../services/map-entities.helper';
import { GeoNodeHelper } from '../services/geoNode.helper';
import { Chamber } from '../../entities/models/chamber';
import { Position, Point, LineString } from '../../common/geo/geometry';
import { Helper } from '../../common/helper';
import { Pole } from '../../entities/models/pole';
import * as _ from "lodash";
import { Splitter } from '../../entities/models/splitter';
import { Cable } from '../../entities/models/cable';
import { SpliceClosure } from 'src/app/entities/models/spliceClosure';
import { Supplier } from 'src/app/common/models/supplier';


declare var $: any;
declare var google: any;
declare var GMHelper: any;
declare var entitiesHelper: any;
declare var fromComponent: any;

@Component({
   selector: 'dzn-map',
   templateUrl: './dzn-map.html'
})
export class DesignMap implements OnInit, OnChanges {

   @Input() public design: Design = new Design();

   private entityIcons = [];
   layers = [];
   map: any;
   isEntitiesGenerated: boolean = false;
   entitiesHelper: EntitiesHelper;
   mapEntitiesHelper: MapEntitiesHelper;
   selectedEntity: any;
   changedSegments = [];
   selectedLayers = ["Cable", "Chamber", "Pole", "Splitter"];

   des: any;

   constructor(
      private appConfig: AppConfig,
      private bomHelper: BomHelper) {

      this.entityIcons.push({ entityType: "Homepass", icon: { url: "images/map-entities/homepass.png" } });
      this.entityIcons.push({ entityType: "Chamber", icon: { url: "images/map-entities/chamber.png", anchor: new google.maps.Point(10, 10) } });
      this.entityIcons.push({ entityType: "ODF", icon: { url: "images/map-entities/odf.png" } });
      this.entityIcons.push({ entityType: "Pole", icon: { url: "images/map-entities/pole.png" } });
      this.entityIcons.push({ entityType: "Splitter", icon: { url: "images/map-entities/splitter.png" } });
      this.entityIcons.push({ entityType: "SpliceClosure", icon: { url: "images/map-entities/spliceclosure.png" } });

      this.layers.push({ id: "Cable", name: "Cable" });
      this.layers.push({ id: "Chamber", name: "Chamber" });
      this.layers.push({ id: "ODF", name: "ODF" });
      this.layers.push({ id: "Pole", name: "Pole" });
      this.layers.push({ id: "SpliceClosure", name: "Splice Closure" });
      this.layers.push({ id: "Splitter", name: "Splitter" });
      this.layers.push({ id: "Homepass", name: "Homepass" });

      this.isEntitiesGenerated = false;
   }

   ngOnInit() {

      this.selectedEntity = null;

      let location = GMapsHelper.getLatLng(this.appConfig.settings.MapCenter);

      if (this.design.bluePrint) {
         location = GeoHelper.convertToPosition(this.design.bluePrint.coordinates);
      }

      this.map = GMapsHelper.initializeMap('designMap', location, 18, 21);
      this.mapEntitiesHelper = new MapEntitiesHelper(this.map);
      var overlay = GMHelper.createOverlay(this.map);

      var entityItems = $('.entityMenu img');

      this.entitiesHelper = new EntitiesHelper(this.design.bookingIds, this.design.generatedCodes);
      let mapEntitiesHelper = new MapEntitiesHelper(this.map);




      let des = this.des;

      for (var i = 0; i < entityItems.length; i++) {

         $(entityItems[i]).draggable({

            helper: 'clone', containment: '#designMap',

            stop: (e) => {


               let seg = this.design.bluePrint.children[0].segments;
               var dropPoint = new google.maps.Point(e.pageX - 250, e.pageY - 200);
               var entityType = e.target.attributes[1].nodeValue;

               var latLng = GMHelper.getLatLongFromDragPoint(overlay, dropPoint);

               if (entityType == "Chamber") {
                  //let chamber = this.entitiesHelper.createChamber(new Chamber(), [latLng.lng(), latLng.lat()]);


                  if (seg) {
                     if (seg[0].chambers == null) {
                        seg[0].chambers = new Array<Chamber>();

                        let chamber = new Chamber();
                        chamber.entityType = "Chamber";
                        chamber.id = Helper.generateObjectId();
                        var Uid = chamber.id.toString();
                        chamber.name = Uid.substring(0, 4);
                        chamber.code = chamber.name;
                        chamber.geometry = new Point([latLng.lng(), latLng.lat()]);

                        var marker = mapEntitiesHelper.drawPoint(chamber, { url: "images/map-entities/chamber.png", anchor: new google.maps.Point(10, 10) }, true, true);

                        let supplier = new Supplier();
                        supplier.currency = "dollar";
                        supplier.name = "supplier1";
                        supplier.stockQty = 7
                        supplier.price = 1200;
                        supplier.validFrom = "2019-12-18";
                        supplier.validTo = "2019-12-25";

                        chamber.suppliers = new Array<Supplier>();
                        chamber.suppliers.push(supplier);

                        seg[0].chambers.push(chamber);
                        GMapsHelper.addListener(marker, 'click', (event) => {

                           this.selectedEntity = marker.data;
                        });
                        this.isEditable(true, marker);
                     }
                     else {
                        var ChamberLength = seg[0].chambers.length + 1;
                        let newChamber = _.cloneDeep(seg[0].chambers[0]);

                        newChamber.id = Helper.generateObjectId();
                        newChamber.code = 'Chamber_' + ChamberLength;
                        newChamber.name = 'Chamber_' + ChamberLength;
                        newChamber.geometry = new Point([latLng.lng(), latLng.lat()]);

                        var marker = mapEntitiesHelper.drawPoint(newChamber, { url: "images/map-entities/chamber.png", anchor: new google.maps.Point(10, 10) }, true, true);

                        seg[0].chambers.push(newChamber);
                        GMapsHelper.addListener(marker, 'click', (event) => {

                           this.selectedEntity = marker.data;
                        });
                        this.isEditable(true, marker);
                     }


                  }


               }

               if (entityType == "Pole") {
                  if (seg) {
                     if (seg[0].poles == null) {
                        seg[0].poles = new Array<Pole>();

                        let pole = new Pole();
                        pole.entityType = "Pole";
                        pole.id = Helper.generateObjectId();
                        var Uid = pole.id.toString();
                        pole.code = Uid.substring(0, 4);
                        pole.name = pole.code;
                        pole.geometry = new Point([latLng.lng(), latLng.lat()]);

                        var marker = mapEntitiesHelper.drawPoint(pole, { url: "images/map-entities/pole.png", anchor: new google.maps.Point(10, 10) }, true, true);


                        let supplier = new Supplier();
                        supplier.currency = "dollar";
                        supplier.name = "supplier1";
                        supplier.stockQty = 7
                        supplier.price = 1200;
                        supplier.validFrom = "2019-12-18";
                        supplier.validTo = "2019-12-25";

                        pole.suppliers = new Array<Supplier>();
                        pole.suppliers.push(supplier);

                        seg[0].poles.push(pole);

                        GMapsHelper.addListener(marker, 'click', (event) => {

                           this.selectedEntity = marker.data;
                        });
                        this.isEditable(true, marker);
                     }
                     else {

                        let newPole = _.cloneDeep(seg[0].poles[0]);
                        var PoleLength = seg[0].poles.length + 1;
                        newPole.id = Helper.generateObjectId();
                        newPole.code = 'Poles_' + PoleLength;
                        newPole.name = 'Poles_' + PoleLength;
                        //newPole.name = newPole.code;
                        newPole.geometry = new Point([latLng.lng(), latLng.lat()]);

                        var marker = mapEntitiesHelper.drawPoint(newPole, { url: "images/map-entities/pole.png", anchor: new google.maps.Point(10, 10) }, true, true);

                        seg[0].poles.push(newPole);
                        GMapsHelper.addListener(marker, 'click', (event) => {

                           this.selectedEntity = marker.data;
                        });
                        this.isEditable(true, marker);
                     }

                  }
               }
               if (entityType == "SpliceClosure") {
                  if (seg) {
                     if (seg[0].spliceClosures == null) {
                        seg[0].spliceClosures = new Array<SpliceClosure>();

                        let spliceclosures = new SpliceClosure();
                        spliceclosures.entityType = "SpliceClosure";
                        spliceclosures.id = Helper.generateObjectId();
                        var Uid = spliceclosures.id.toString();
                        spliceclosures.code = Uid.substring(0, 4);
                        spliceclosures.name = spliceclosures.code;
                        spliceclosures.geometry = new Point([latLng.lng(), latLng.lat()]);

                        var marker = mapEntitiesHelper.drawPoint(spliceclosures, { url: "images/map-entities/spliceclosure.png", anchor: new google.maps.Point(10, 10) }, true, true);



                        let supplier = new Supplier();
                        supplier.currency = "dollar";
                        supplier.name = "supplier1";
                        supplier.stockQty = 7
                        supplier.price = 1200;
                        supplier.validFrom = "2019-12-18";
                        supplier.validTo = "2019-12-25";

                        spliceclosures.suppliers = new Array<Supplier>();
                        spliceclosures.suppliers.push(supplier);

                        seg[0].spliceClosures.push(spliceclosures);

                        GMapsHelper.addListener(marker, 'click', (event) => {

                           this.selectedEntity = marker.data;
                        });
                        this.isEditable(true, marker);
                     }
                     else {

                        let spliceClosure = _.cloneDeep(seg[0].spliceClosures[0]);
                        var spliceClosureLength = seg[0].spliceClosures.length + 1;
                        spliceClosure.id = Helper.generateObjectId();
                        spliceClosure.code = 'SpliceClosure_' + spliceClosureLength;
                        spliceClosure.name = 'SpliceClosure_' + spliceClosureLength;
                        //newPole.name = newPole.code;
                        spliceClosure.geometry = new Point([latLng.lng(), latLng.lat()]);

                        var marker = mapEntitiesHelper.drawPoint(spliceClosure, { url: "images/map-entities/spliceclosure.png", anchor: new google.maps.Point(10, 10) }, true, true);

                        seg[0].spliceClosures.push(spliceClosure);
                        GMapsHelper.addListener(marker, 'click', (event) => {

                           this.selectedEntity = marker.data;
                        });
                        this.isEditable(true, marker);
                     }

                  }
               }
               //createEntity(entityType, latLng);
               if (entityType == "Splitter") {
                  if (seg) {
                     if (seg[0].splitters == null) {
                        seg[0].splitters = new Array<Splitter>();

                        let splitters = new Splitter();
                        splitters.entityType = "Splitter";
                        splitters.id = Helper.generateObjectId();
                        var Uid = splitters.id.toString();
                        splitters.code = Uid.substring(0, 4);
                        splitters.name = splitters.code;

                        splitters.geometry = new Point([latLng.lng(), latLng.lat()]);

                        var marker = mapEntitiesHelper.drawPoint(splitters, { url: "images/map-entities/spliceclosure.png", anchor: new google.maps.Point(10, 10) }, true, true);



                        let supplier = new Supplier();
                        supplier.currency = "dollar";
                        supplier.name = "supplier1";
                        supplier.stockQty = 7
                        supplier.price = 1200;
                        supplier.validFrom = "2019-12-18";
                        supplier.validTo = "2019-12-25";

                        splitters.suppliers = new Array<Supplier>();
                        splitters.suppliers.push(supplier);

                        seg[0].splitters.push(splitters);

                        GMapsHelper.addListener(marker, 'click', (event) => {

                           this.selectedEntity = marker.data;
                        });
                        this.isEditable(true, marker);
                     }
                     else {

                        let splitters = _.cloneDeep(seg[0].splitters[0]);
                        var splittersLength = seg[0].splitters.length + 1;
                        splitters.id = Helper.generateObjectId();
                        splitters.code = 'Splitter_' + splittersLength;
                        splitters.name = 'Splitters_' + splittersLength;
                        //newPole.name = newPole.code;
                        splitters.geometry = new Point([latLng.lng(), latLng.lat()]);

                        var marker = mapEntitiesHelper.drawPoint(splitters, { url: "images/map-entities/splitter.png", anchor: new google.maps.Point(10, 10) }, true, true);

                        seg[0].splitters.push(splitters);
                        GMapsHelper.addListener(marker, 'click', (event) => {

                           this.selectedEntity = marker.data;
                        });
                        this.isEditable(true, marker);
                     }

                  }
               }

               if (entityType == "Cable") {


                  //var marker = mapEntitiesHelper.drawLine(cable, "#000000", 2, false, true);

                  var parentThis = this;
                  let colour = "#000000";
                  let lineWeight = 3;



                  let polyline = new google.maps.Polyline({
                     strokeColor: colour,
                     strokeOpacity: 1.0,
                     strokeWeight: lineWeight,
                     map: this.map
                  });

                  let path = polyline.getPath();

                  polyline.setMap(this.map);

                  GMHelper.clearClickListener(this.map, "click");

                  GMHelper.addListener(this.map, "click", function (event) {
                     polyline.setEditable(true);
                     path = polyline.getPath();
                     path.push(event.latLng);
                  });

                  this.map.setOptions({ draggableCursor: 'crosshair' });

                  GMHelper.addListener(polyline, "rightclick", function (event) {
                     GMHelper.clearClickListener(polyline, "rightclick");

                     GMHelper.clearClickListener(polyline.map, "click");

                     polyline.map.setOptions({ draggableCursor: '' });

                     polyline.setEditable(false);


                     let seg1 = new Segment();// this.design.bluePrint.children[0].segments;

                     seg1.id = Helper.generateObjectId();



                     let cable = new Cable();
                     cable.entityType = "Cable";
                     cable.id = Helper.generateObjectId();
                     var ids = cable.id.toString();
                     cable.name = "Cable_" + ids.substring(0, 3);
                     cable.code = "Cable_" + ids.substring(0, 3);;

                     seg1.cable = cable;

                     //this.isEditable(true, marker);

                     var coords = polyline.getPath().getArray();

                     let newCoords = new Array<number[]>();

                     coords.forEach(x => {
                        newCoords.push([x.lng(), x.lat()]);
                     });

                     cable.geometry = new LineString();
                     cable.geometry.coordinates = GeoHelper.cleanLineCoordinates(newCoords);

                     cable.measuredLength = GeoHelper.getLength(cable.geometry.coordinates);



                     let supplier = new Supplier();
                     supplier.currency = "dollar";
                     supplier.name = "supplier1";
                     supplier.stockQty = 7
                     supplier.price = 1200;
                     supplier.validFrom = "2019-12-18";
                     supplier.validTo = "2019-12-25";

                     cable.suppliers = new Array<Supplier>();
                     cable.suppliers.push(supplier);

                     seg1.coordinates = cable.geometry.coordinates;

                     seg1.cable = cable;


                     parentThis.design.bluePrint.children[0].segments.push(seg1);

                     var marker = mapEntitiesHelper.drawLine(cable, "#000000", 2, false, true);
                     //this.selectedEntity = polyline.data;


                     GMapsHelper.addListener(marker, 'click', (event) => {
                        parentThis.selectedEntity = marker.data;
                     });
                  });

                  //GMapsHelper.addListener(polyline, 'click', (event) => {
                  //   this.selectedEntity = polyline.data;
                  //});






                  //else {
                  //    let array = [];
                  //    array.push(seg[0].cable);
                  //    let cables = seg[0].cable;
                  //    var cableLength = array.length + 1;
                  //    cables.id = Helper.generateObjectId();
                  //    cables.code = 'Cable_' + cableLength;
                  //    cables.name = 'Cable_' + cableLength;
                  //    var marker = mapEntitiesHelper.drawLine(cables, "#000000", 2, false, true);
                  //    seg[0].cable = cables;
                  //    GMapsHelper.addListener(marker, 'click', (event) => {
                  //        this.selectedEntity = marker.data;
                  //    });
                  //}

               }
               //createEntity(entityType, latLng);
            }
         });
      }

   }
   isEditable(value, marker) {
      if (value) {

         GMapsHelper.addListener(marker, "rightclick", (event) => {

            if (marker.draggable)
               marker.setDraggable(false);
            else
               marker.setDraggable(true);

         });

         GMapsHelper.addListener(marker, 'dragend', (event) => {
            var latLng = event.latLng;
            marker.data.geometry.coordinates = [latLng.lng(), latLng.lat()];

            //let index = this.changedSegments.findIndex(x => (x.levelId == marker.data.levelId && x.segmentId == marker.data.segmentId));

            //if (index == -1)
            //   this.changedSegments.push({ levelId: marker.data.levelId, segmentId: marker.data.segmentId });

         });
      }
   }
   ngOnChanges(changes: SimpleChanges) {

      this.selectedEntity = null;

      if (this.design.bluePrint && this.design.bluePrint.children && this.design.bluePrint.children.length > 0) {

         this.entitiesHelper = new EntitiesHelper(this.design.bookingIds, this.design.generatedCodes);

         this.generateMapEntities(this.design.bluePrint);

         this.isEntitiesGenerated = true;

         this.map.setCenter({ lat: this.design.bluePrint.coordinates[1], lng: this.design.bluePrint.coordinates[0] });
      }
      else {
         this.isEntitiesGenerated = false;
      }

      this.des = this.design.bluePrint;
   }

   isAllSelected() {
      const numSelected = this.selectedLayers ? this.selectedLayers.length : 0;
      const numRows = this.layers.length;
      return numSelected === numRows;
   }

   toggleSelection(layer: any) {

      var index = -1;

      if (this.selectedLayers)
         index = this.selectedLayers.findIndex(x => x == layer.id);
      else
         this.selectedLayers = [];

      if (index == -1)
         this.selectedLayers.push(layer.id);
      else
         this.selectedLayers.splice(index, 1);
   }

   masterToggle() {

      if (this.isAllSelected()) {
         this.selectedLayers = [];
      }
      else {
         this.selectedLayers = [];
         this.layers.forEach(x => this.selectedLayers.push(x.id));
      }
   }

   refreshLayers() {

      if (this.design.bluePrint) {

         if (this.isEntitiesGenerated == false) {
            this.generateMapEntities(this.design.bluePrint);
            this.isEntitiesGenerated = true;
            this.map.setCenter({ lat: this.design.bluePrint.coordinates[1], lng: this.design.bluePrint.coordinates[0] });
         }
      }

      this.toggleEntities(this.design.bluePrint);
   }

   refreshBlueprint() {

      $("#ajax-loading").show();

      this.entitiesHelper = new EntitiesHelper(this.design.bookingIds, this.design.generatedCodes);

      this.changedSegments.forEach(x => {

         this.refreshSegment(this.design.bluePrint, x.levelId, x.segmentId);

      });


      this.bomHelper.generateBOQ(this.design);

      $("#ajax-loading").hide();
   }

   refreshSegment(geoNode: GeoNode, levelId, segmentId) {

      if (geoNode.segments) {

         let segment = geoNode.segments.find(x => x.id == segmentId);

         if (segment) {

            if (segment.chambers && segment.chambers.length > 0) {

               segment.coordinates = segment.cable.geometry.coordinates;

               this.mapEntitiesHelper.removeMapObjects(segment.chambers);

               segment.chambers = this.entitiesHelper.createChambers(segment.chambers[0], 100, segment,10,10);

               this.plotPointEntities(segment.chambers, "Chamber", levelId, segmentId, true, true);
            }

            if (segment.poles && segment.poles.length > 0) {

               segment.coordinates = segment.cable.geometry.coordinates;

               this.mapEntitiesHelper.removeMapObjects(segment.poles);

               segment.poles = this.entitiesHelper.createPoles(segment.poles[0], 100, segment,10,10);
               this.plotPointEntities(segment.poles, "Pole", levelId, segmentId, true, true);
            }

            return false;
         }
      }

      if (geoNode.children && geoNode.children.length > 0)
         geoNode.children.forEach(g => {
            this.refreshSegment(g, g.id, segmentId);
         });
   }

   toggleEntities(group: GeoNode) {

      if (group.children) {
         group.children.forEach(x => {

            if (x.levelName == "homepasses") {
               //this.toggleEntity(x, this.selectedLayers.includes("Homepass"));
               this.setEntitiesVisible(x, this.selectedLayers.includes("Homepass"));
            }

            //if (x.level == "Feeder") {
            //    this.toggleEntity(x, this.selectedLayers.includes("Splitter"));
            //}
         });
      }

      if (group.segments)
         group.segments.forEach(x => {

            this.setEntitiesVisible(x.cable, this.selectedLayers.includes("Cable"));

            this.setEntitiesVisible(x.chambers, this.selectedLayers.includes("Chamber"));

            this.setEntitiesVisible(x.odfs, this.selectedLayers.includes("ODF"));

            this.setEntitiesVisible(x.poles, this.selectedLayers.includes("Pole"));

            this.setEntitiesVisible(x.splitters, this.selectedLayers.includes("Splitter"));

            this.setEntitiesVisible(x.spliceClosures, this.selectedLayers.includes("SpliceClosure"));

         });

      if (group.children && group.children.length > 0)
         group.children.forEach(g => {
            this.toggleEntities(g);
         });

   }

   setEntitiesVisible(entities, isVisible) {

      if (entities) {
         if (entities.length > 0) {
            entities.forEach(x => {
               if (x && x['mapObject']) {
                  x['mapObject'].setVisible(isVisible);
               }
            });
         }
         else {
            if (entities['mapObject']) {
               entities['mapObject'].setVisible(isVisible);
            }
         }
      }
   }

   generateMapEntities(group: GeoNode) {

      let levelId = group.id;

      if (group.children)
         group.children.forEach(x => {

            if (x.levelName == "homepasses") {
               //x['entityType'] = "Homepass";
               //let entityIcon = this.entityIcons.find(i => i.entityType == 'Homepass');
               //this.drawPoint(x, entityIcon.icon, false);

               this.plotPointEntities(x, "Homepass", levelId, x.id, true, true);
            }
            //else {
            //    x['entityType'] = "Splitter";
            //    let entityIcon = this.entityIcons.find(i => i.entityType == 'Splitter');
            //    this.drawPoint(x, entityIcon.icon, true);
            //}
         });

      if (group.segments)
         group.segments.forEach(x => {

            this.plotLineEntities(x.cable, "Cable", levelId, x.id, true, true);

            this.plotPointEntities(x.chambers, "Chamber", levelId, x.id, true, true);

            this.plotPointEntities(x.odfs, "ODF", levelId, x.id, true, true);

            this.plotPointEntities(x.poles, "Pole", levelId, x.id, true, true);

            this.plotPointEntities(x.splitters, "Splitter", levelId, x.id, true, true);

            this.plotPointEntities(x.spliceClosures, "SpliceClosure", levelId, x.id, true, true);

         });

      if (group.children && group.children.length > 0)
         group.children.forEach(g => {
            this.generateMapEntities(g);
         });

   }

   plotPointEntities(entities: any, entityType: string, levelId: string, segmentId: string, isEditable: boolean, attachMapObject: boolean) {

      let entityIcon = this.entityIcons.find(i => i.entityType == entityType);

      if (entities) {

         if (entities.length > 0) {
            entities.forEach(x => {
               this.plotPointEntity(x, entityIcon.icon, levelId, segmentId, isEditable, attachMapObject);
            });
         }
         else {
            this.plotPointEntity(entities, entityIcon.icon, levelId, segmentId, isEditable, attachMapObject);
         }
      }
   }

   plotPointEntity(entity: any, entityIcon: any, levelId: string, segmentId: string, isEditable: boolean, attachMapObject: boolean) {

      if (entity) {

         entity["levelId"] = levelId;
         entity["segmentId"] = segmentId;

         let marker = this.mapEntitiesHelper.drawPoint(entity, entityIcon, isEditable, attachMapObject);

         GMapsHelper.addListener(marker, 'click', (event) => {
            if (marker.data.levelName == "homepasses") {
               let homepass = this.design.homepasses.find(x => x.id == marker.data.id);
               if (homepass) {
                  this.selectedEntity = homepass;
                  this.selectedEntity["entityType"] = "Homepass";
               }
            }
            else
               this.selectedEntity = marker.data;
         });

         if (isEditable) {

            GMapsHelper.addListener(marker, "rightclick", (event) => {

               if (marker.draggable)
                  marker.setDraggable(false);
               else
                  marker.setDraggable(true);

            });

            GMapsHelper.addListener(marker, 'dragend', (event) => {
               var latLng = event.latLng;
               marker.data.geometry.coordinates = [latLng.lng(), latLng.lat()];

               //let index = this.changedSegments.findIndex(x => (x.levelId == marker.data.levelId && x.segmentId == marker.data.segmentId));

               //if (index == -1)
               //   this.changedSegments.push({ levelId: marker.data.levelId, segmentId: marker.data.segmentId });

            });
         }
      }
   }

   plotLineEntities(entities: any, entityType: string, levelId: string, segmentId: string, isEditable: boolean, attachMapObject: boolean) {

      if (entities) {
         if (entities.length > 0) {
            entities.forEach(x => {
               this.plotLineEntity(x, levelId, segmentId, isEditable, attachMapObject);
            });
         }
         else {
            this.plotLineEntity(entities, levelId, segmentId, isEditable, attachMapObject);
         }
      }
   }

   plotLineEntity(entity: any, levelId: string, segmentId: string, isEditable: boolean, attachMapObject: boolean) {

      if (entity) {

         entity["levelId"] = levelId;
         entity["segmentId"] = segmentId;

         let polyLine = this.mapEntitiesHelper.drawLine(entity, "#000", 2, isEditable, attachMapObject);

         GMapsHelper.addListener(polyLine, 'click', (event) => {
            this.selectedEntity = polyLine.data;
         });

         if (isEditable) {

            GMapsHelper.addListener(polyLine, "rightclick", (event) => {

               if (polyLine.editable)
                  polyLine.setEditable(false);
               else
                  polyLine.setEditable(true);
            });

            GMapsHelper.addListener(polyLine.getPath(), 'set_at', () => {

               var coords = polyLine.getPath().getArray();

               let newCoords = new Array<number[]>();

               coords.forEach(x => {
                  newCoords.push([x.lng(), x.lat()]);
               });


               polyLine.data.geometry.coordinates = GeoHelper.cleanLineCoordinates(newCoords);

               polyLine.data.measuredLength = GeoHelper.getLength(polyLine.data.geometry.coordinates);

               let index = this.changedSegments.findIndex(x => (x.levelId == polyLine.data.levelId && x.segmentId == polyLine.data.segmentId));

               if (index == -1)
                  this.changedSegments.push({ levelId: polyLine.data.levelId, segmentId: polyLine.data.segmentId });

            });
         }
      }
   }

   deleteEntity() {

      this.mapEntitiesHelper.removeMapObjects(this.selectedEntity);
      GeoNodeHelper.deleteSegmentEntity(this.design.bluePrint, this.selectedEntity.id, this.selectedEntity.entityType);
      this.selectedEntity = null;

      this.refreshBlueprint();
   }

   stringify(object: any) {
      return JSON.stringify(object);
   }
}
