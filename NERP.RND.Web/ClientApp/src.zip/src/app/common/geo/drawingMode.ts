export enum DrawingMode {
    CIRCLE,
    MARKER,
    POLYGON,
    POLYLINE,
    RECTANGLE
}
