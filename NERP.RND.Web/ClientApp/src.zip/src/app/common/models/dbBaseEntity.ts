export class DbBaseEntity {
   id?: string;
   createdBy?: string;
   createdDate?: string;
   updatedBy?: string;
   updatedDate?: string;
}
