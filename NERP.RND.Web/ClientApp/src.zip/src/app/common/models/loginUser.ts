export class LoginUser {
    id: string;
    loginId: string;
    name: string;
    features: string[];
    permissions: string[];
    token: string;
}
