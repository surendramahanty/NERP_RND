export class PaginationResponse {
   status: string;
   message: string;
   data: any;
   recordCount: number;
   miscData: any;
   draw: number;
}
