export class BookingId {
    entityType: string;
    format: string;
    sequenceStart?: number;
    sequenceEnd?: number;
    step?: number;
}
