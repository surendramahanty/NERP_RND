export class SearchField {
    field: string;
    label: string;
    dataType: string;
    value: any;
}
