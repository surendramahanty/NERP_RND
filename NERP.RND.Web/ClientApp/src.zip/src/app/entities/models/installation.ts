export class Installation {
    number: string;
    year?: number;
    company: string;
    technician: string;
    productionYear?: number;
    date?: string;
}
