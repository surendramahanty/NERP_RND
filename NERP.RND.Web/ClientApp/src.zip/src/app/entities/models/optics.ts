export class Optics {
    frequency?: number;
    attenuationDb?: number;
    resistanceOhm?: number;
    opticalInPutPower?: number;
    opticalOutputPower?: number;
    wavelength?: number;
}
