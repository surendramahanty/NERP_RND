export class Owner {
    name: string;
    address: string;
    mobileNumber: string;
    fax: string;
    emailId: string;
}
