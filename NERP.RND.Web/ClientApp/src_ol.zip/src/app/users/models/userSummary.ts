export class UserSummary {
   id: string;

   loginId: string;
   firstName: string;
   lastName: string;
   emailId: string;
   roleName: string;
   isActive: boolean;
}
