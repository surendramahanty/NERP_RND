import { DrawingMode } from './drawingMode';
import { GeoHelper } from './geoHelper';
import { Position } from './geometry';

declare var google: any;

declare var ria: any;
declare var OpenLayers: any;
declare var window: any;
declare var ol: any;

export class GMapsHelper {

   static initializeMap(mapElementId, mapCenter, zoom, maxZoom) {

      ria.RestService.addProxy('/riaproxy/?url=');


      // Get all html elements for map
      var mapElement = document.getElementById(mapElementId);


      var apiKey = "AmNbl1XqrIQVy1RWC2v4ownaDYnyt6n5lEsmTDCQLXWSTaX74eQ7652WWC6XmLL3";

      var map = new OpenLayers.Map(mapElement, ria.ol.defaultMapOptions('EPSG:3857'));

      var road = new OpenLayers.Layer.Bing({
         key: apiKey,
         type: "Road",
         metadataParams: { mapVersion: "v1" }
      });

      var vectorLayer = new OpenLayers.Layer.Vector({
         source: new OpenLayers.Layer.Vector(),
      });

      map.addLayers([road, vectorLayer]);


      //var map = new OpenLayers.Map({
      //   div: mapElement,
      //   allOverlays: true,
      //   layers: [road, vectorLayer],
      //   eventListeners: {
      //      //featureover: function (e) {
      //      //   e.feature.renderIntent = "select";
      //      //   e.feature.layer.drawFeature(e.feature);
      //      //   console.log("Map says: Pointer entered " + e.feature.id + " on " + e.feature.layer.name);
      //      //},
      //      //featureout: function (e) {
      //      //   e.feature.renderIntent = "default";
      //      //   e.feature.layer.drawFeature(e.feature);
      //      //   console.log("Map says: Pointer left " + e.feature.id + " on " + e.feature.layer.name);
      //      //},
      //      featureclick: function (e) {
      //         console.log("Map says: " + e.feature.id + " clicked on " + e.feature.layer.name);
      //      }
      //   }
      //});


      if (mapCenter === null || mapCenter === "")
         map.setCenter(new OpenLayers.LonLat(18.5245649, 73.7228783).transform('EPSG:4326', 'EPSG:3857'), zoom);
      else
         map.setCenter(new OpenLayers.LonLat(mapCenter.lon, mapCenter.lat).transform('EPSG:4326', 'EPSG:3857'), zoom);

      return map;

   }

   static drawingManagerTool(map, strDrawingMode, drawingControlModes, drawingOption) {

      var drawingManager = new google.maps.drawing.DrawingManager();

      var drawingMode = GMapsHelper.getDrawingMode(strDrawingMode);

      drawingManager.setOptions({
         drawingMode: drawingMode,
         drawingControl: true,
         drawingControlOptions: {
            position: google.maps.ControlPosition.TOP_LEFT,
            drawingModes: drawingControlModes
         },
         options: drawingOption
      });

      drawingManager.setMap(map);

      return drawingManager;
   }

   static addListener(entity, clickType, callback) {
      google.maps.event.addListener(entity, clickType, function (event) {
         if (typeof callback === "function")
            callback(event);
      });
   }

   static getDrawingMode(drawingMode: DrawingMode) {

      switch (drawingMode) {
         case DrawingMode.POLYGON:
            return google.maps.drawing.OverlayType.POLYGON;
         case DrawingMode.CIRCLE:
            return google.maps.drawing.OverlayType.CIRCLE;
         case DrawingMode.POLYLINE:
            return google.maps.drawing.OverlayType.POLYLINE;
         case DrawingMode.RECTANGLE:
            return google.maps.drawing.OverlayType.RECTANGLE;
         case DrawingMode.MARKER:
            return google.maps.drawing.OverlayType.MARKER;
         default:
      }
   }

   static createPolygon(coordinates: Array<Array<Position>>, polyOptions: any) {

      let tempCoordinates = GMapsHelper.getLatLngsFromPolygon(coordinates);

      return new google.maps.Polygon({
         paths: tempCoordinates,
         strokeWeight: polyOptions.strokeWeight,
         fillOpacity: polyOptions.fillOpacity,
         editable: polyOptions.editable,
         draggable: polyOptions.draggable
      });
   }

   static getLatLngsFromPolygon(coordinates: Array<Array<Position>>) {

      var tempCoordinates = [];

      coordinates[0].forEach(x => { tempCoordinates.push({ lng: x[0], lat: x[1] }) });

      tempCoordinates.splice(tempCoordinates.length - 1, 1);

      return tempCoordinates;
   }

   static setBounds(latlngs: any, map: any) {

      var bounds = new google.maps.LatLngBounds();
      for (var i = 0; i < latlngs.length; i++) {
         bounds.extend(latlngs[i]);
      }

      map.fitBounds(bounds);
   }

   static getLatLng(latlng: number[]) {
      return new OpenLayers.LonLat(latlng[0], latlng[1]);
   }

   static getEPSG3ToEPSG4(latlng:any) {
      return new OpenLayers.Geometry.Point(latlng.lon, latlng.lat).transform(new OpenLayers.Projection('EPSG:3857'), new OpenLayers.Projection('EPSG:4326')); //From , To
   }

   static boundsToPolygon(bounds: any): Array<Array<Position>> {

      let northEastLatLngs = [];
      let southWestLatLngs = [];
      let northWestLatLngs = [];
      let southEastLatLngs = [];

      northEastLatLngs[0] = bounds.getNorthEast().lng();
      northEastLatLngs[1] = bounds.getNorthEast().lat();

      northWestLatLngs[0] = bounds.getSouthWest().lng();
      northWestLatLngs[1] = bounds.getNorthEast().lat();

      southWestLatLngs[0] = bounds.getSouthWest().lng();
      southWestLatLngs[1] = bounds.getSouthWest().lat();

      southEastLatLngs[0] = bounds.getNorthEast().lng();
      southEastLatLngs[1] = bounds.getSouthWest().lat();

      var tempCoordinates = [];
      tempCoordinates.push(northEastLatLngs);
      tempCoordinates.push(northWestLatLngs);
      tempCoordinates.push(southWestLatLngs);
      tempCoordinates.push(southEastLatLngs);
      tempCoordinates.push(northEastLatLngs);

      return [tempCoordinates];

   }

   static pathArrayToPolygon(pathArray: any): Array<Array<Position>> {

      var tempCoordinates = [];

      pathArray.forEach(x => { tempCoordinates.push([x.lng(), x.lat()]); });

      tempCoordinates.push([pathArray[0].lng(), pathArray[0].lat()]);

      return [tempCoordinates];
   }

   static getPointsAtDistance(points: Position[], distance: number) {

      let path = [];

      points.forEach(x => { path.push({ lng: x[0], lat: x[1] }) });

      return new google.maps.Polyline({
         path: path
      }).GetPointsAtDistance(distance);
   }
}
