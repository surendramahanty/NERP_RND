export class Document {
    id: string;
    category: string;
    fileName: string;
    fileSize: number;
    filePath: string;

    file: any;
}
