export class ServiceResponse {
    status: string;
    messageId: number;
    message: string;
    data: any;
    recordCount: number;
    miscData: any;
}