export class FileAttachment {
    id: string;
    fileName: string;
    fileSize: number;
    filePath: string;
}
