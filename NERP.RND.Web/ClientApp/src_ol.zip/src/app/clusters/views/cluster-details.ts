import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { ClusterService } from '../services/cluster.service';
import { HomepassService } from '../../homepasses/services/homepass.service';
import { Helper } from '../../common/helper';
import { GMapsHelper } from '../../common/geo/googleMapsHelper';
import { AppConfig } from '../../app.config';
import { Cluster } from '../models/cluster';
import { Point, Polygon } from '../../common/geo/geometry';
import { Homepass } from '../../homepasses/models/homepass';
import { ServiceResponse } from '../../common/models/serviceResponse';
import { async } from '@angular/core/testing';

declare var $: any;
declare var shp: any;
declare var toGeoJSON: any;
declare var OpenLayers: any;
declare var ria: any;

@Component({
   templateUrl: './cluster-details.html',
   providers: [ClusterService],
})
export class ClusterDetails implements OnInit {

   polyOptions: any;
   map: any;
   drawingManager: any;

   clusterId: string;
   title: string = "New Cluster";
   tabTitle: string = "Add New";
   isNew = true;
   cluster: Cluster;
   clusters: Cluster[] = new Array<Cluster>();

   constructor(
      private location: Location,
      private route: ActivatedRoute,
      private httpClient: HttpClient,
      private appConfig: AppConfig,
      private clusterService: ClusterService,
      private homepassService: HomepassService,
      private helper: Helper) {

      this.polyOptions = {
         strokeWeight: 0,
         fillOpacity: 0.45,
         editable: false,
         draggable: false
      };
   }

   ngOnInit() {

      this.route.params.subscribe(
         params => {
            this.clusterId = params['id'];

            if (this.clusterId == null) {
               this.title = "New Cluster";
               this.isNew = true;
            }
            else {
               this.title = "Edit Cluster";
               this.tabTitle = "Edit Cluster";
               this.isNew = false;
            }

            this.getFormData(this.clusterId);
         });
   }

   onInitializeClusterMap(isEdit) {

      var parentThis = this;

      setTimeout(() => {
         if (!this.map) {

            $("#tab_map").css("display", "block");

            let location = GMapsHelper.getLatLng(this.appConfig.settings.MapCenter);
            //this.map = GMapsHelper.initializeMap('clusterMap', location, 18, 21);


            // Get all html elements for map
            var mapElement = document.getElementById('clusterMap');


            var apiKey = "AmNbl1XqrIQVy1RWC2v4ownaDYnyt6n5lEsmTDCQLXWSTaX74eQ7652WWC6XmLL3";

            var road = new OpenLayers.Layer.Bing({
               key: apiKey,
               type: "Road",
               metadataParams: { mapVersion: "v1" }
            });

            var vectorLayer = new OpenLayers.Layer.Vector({
               source: new OpenLayers.Layer.Vector(),
            });


            this.map = new OpenLayers.Map({
               div: mapElement,
               allOverlays: true,
               layers: [road, vectorLayer],
               eventListeners: {

                  featureclick: function (e) {
                     if (!e.feature.data.data)
                        parentThis.cluster = e.feature.data;
                     else
                        parentThis.cluster = e.feature.data.data;

                  }
               }
            });

            this.map.setCenter(new OpenLayers.LonLat(location.lon, location.lat).transform('EPSG:4326', 'EPSG:3857'), 18);

            $("#tab_map").css("display", "");


            if (isEdit) {
               this.addCluster(this.cluster);
            }
         }

      }, 500);
   }


   getFormData(clusterId: string) {

      this.clusterService.getCluster(clusterId).subscribe(
         async resp => {
            this.cluster = null;
            if (resp.status.toLowerCase() == "error") {
               this.helper.showAlertMessage(resp.message, "error");
            }
            else {
               if (resp.data != null) {
                  var cluster = resp.data;

                  //var polygon = GMapsHelper.createPolygon(cluster.geometry.coordinates, this.polyOptions);

                  //polygon.setMap(this.map);

                  //cluster.marker = polygon;

                  //await this.addHomepasses(cluster);

                 
                  this.cluster = cluster;
                  this.cluster.allHomepasses = await this.getHomepasses(cluster.geometry);
                  this.clusters.push(this.cluster);

                  this.onInitializeClusterMap(true);

                  //var latlngs = GMapsHelper.getLatLngsFromPolygon(cluster.geometry.coordinates);
                  //GMapsHelper.setBounds(latlngs, this.map);

                  //var center = GeoHelper.polygonCenter(this.cluster.geometry);
                  //this.clusterMap.setCenter({ lng: center[0], lat: center[1] });
               }
            }

            $("#ajax-loading").hide();
         },
         (err) => {
            $("#ajax-loading").hide();
            this.cluster = null;
            let msg = `Unable to fetch cluster : ${err.message}`;
            this.helper.showAlertMessage(msg, "error");
         });
   }

   drawSquare() {

      var parentThis = this;

      this.map.addControl(new OpenLayers.Control.MousePosition());
      var drawControls = {
         box: new OpenLayers.Control.DrawFeature(this.map.layers[1], OpenLayers.Handler.RegularPolygon, {
            handlerOptions: {
               sides: 4,
               irregular: true
            }
         })
      };

      var drawControl = drawControls["box"];
      this.map.addControl(drawControl);

      drawControl.activate();

      var clusterLayer = this.map.layers[1];

      clusterLayer.events.on({
         "sketchcomplete": report
      });

      async function report(event) {

         //console.log(event.type, event.feature ? event.feature.id : event.components);

         var tempCoordinates = [];

         $.each(event.feature.geometry.components[0].components, function (i, value) {

            var latLang = new OpenLayers.LonLat(value.x, value.y).transform('EPSG:3857', 'EPSG:4326');
            tempCoordinates.push([latLang.lon, latLang.lat]);
         });

         let cluster = {
            name: "",
            code: "",
            description: "",
            geometry: null,
            homepasses: null,

            marker: event.feature,
            allHomepasses: null
         };

         drawControl.deactivate();

         var cluster1 = await parentThis.getClusterType(cluster, [tempCoordinates]);
         event.feature.data = cluster1;

         parentThis.clusters.push(cluster1);
      }


      //OpenLayers.Control.Click = OpenLayers.Class(OpenLayers.Control, {
      //   defaultHandlerOptions: {
      //      'single': true
      //   },
      //   initialize: function (options) {
      //      this.handlerOptions = OpenLayers.Util.extend(
      //         {}, this.defaultHandlerOptions
      //      );
      //      OpenLayers.Control.prototype.initialize.apply(
      //         this, arguments
      //      );
      //      this.handler = new OpenLayers.Handler.Click(
      //         this, {
      //            'click': this.onClick
      //         }, this.handlerOptions
      //      );
      //   },
      //   onClick: function (evt) {

      //      parentThis.map.forEachFeatureAtPixel(evt.pixel, function (feature, layer) {
      //         //do something
      //         alert("helo");
      //      })
      //   }

      //});
      //var clickControls = { "single": new OpenLayers.Control.Click({ handlerOptions: { "single": true } }) };
      //var clickControl = clickControls["single"];
      //this.map.addControl(clickControl);
      //clickControl.activate();



   }
   drawPolygon() {

   }
   stopDrawing() {

   }

   addCluster(cluster: Cluster) {

      var polyCoords = [];
      $.each(cluster.geometry.coordinates[0], function (i, e) {
         polyCoords.push(new OpenLayers.Geometry.Point(e[0], e[1]).transform('EPSG:4326', 'EPSG:3857'));
      });


      var linearRing = new OpenLayers.Geometry.LinearRing(polyCoords);
      var yourLocation = new OpenLayers.Geometry.Polygon([linearRing]);

      var iconFeature = new OpenLayers.Feature.Vector(yourLocation, { data: cluster, id: cluster.id, code: cluster.code }, { cursor: "pointer", fillColor: "#ee9900", fillOpacity: 0.5, strokeColor: "#ee9900" });

      this.map.layers[1].addFeatures(iconFeature);


      this.map.setCenter(new OpenLayers.LonLat(iconFeature.geometry.bounds.getCenterLonLat()));
      this.map.zoomToExtent(iconFeature.geometry.bounds);

   }


   async getClusterType(cluster: Cluster, coordinates: any) {

      cluster.geometry = new Polygon(coordinates);
      cluster.allHomepasses = await this.getHomepasses(cluster.geometry);

      return cluster;
   }

   async addHomepasses(cluster: Cluster, drawingMode?: string) {

      let polygonArray: any;
      let radius = null;
      let center = null;

      if (drawingMode == 'rectangle') {
         polygonArray = GMapsHelper.boundsToPolygon(cluster.marker.getBounds());
      }
      else if (drawingMode == 'polygon') {
         polygonArray = GMapsHelper.pathArrayToPolygon(cluster.marker.getPath().getArray());
      }
      else {
         polygonArray = GMapsHelper.pathArrayToPolygon(cluster.marker.getPath().getArray());
      }
      //else if (drawingMode == 'circle') {
      //    center = [cluster.marker.center.lng(), cluster.marker.center.lat()];
      //    radius = cluster.marker.getRadius();
      //}

      cluster.geometry = new Polygon(polygonArray);

      if (drawingMode == 'circle')
         cluster.allHomepasses = await this.getHomepassesWithinRadius(center, radius);
      else
         cluster.allHomepasses = await this.getHomepasses(cluster.geometry);

      this.addEventListners(cluster, drawingMode);
   }

   async getHomepassesWithinRadius(center: Point, radius: number) {

      let homepasses = new Array<Homepass>();

      var resp = await this.httpClient.post<ServiceResponse>(this.homepassService.getHomepassesWithinRadiusApi, { Center: center, Radius: radius }).toPromise();

      if (resp.status.toLowerCase() != "error") {
         if (resp.data != null && resp.data.length > 0) {
            homepasses = resp.data;
         }
      }

      return homepasses;

   }

   async getHomepasses(polygon: Polygon) {

      let homepasses = new Array<Homepass>();

      var resp = await this.httpClient.post<ServiceResponse>(this.homepassService.getHomepassesInPolygonApi, polygon).toPromise();

      if (resp.status.toLowerCase() != "error") {
         if (resp.data != null && resp.data.length > 0) {
            homepasses = resp.data;
         }
      }

      return homepasses;

   }

   addEventListners(cluster: Cluster, drawingMode?: string) {

      GMapsHelper.addListener(cluster.marker, "rightclick", (event) => {

         if (cluster.marker.draggable == false) {
            cluster.marker.setOptions({ draggable: true, editable: true });
         }
         else {
            cluster.marker.setOptions({ draggable: false, editable: false });
         }
      });

      //GMapsHelper.addListener(cluster.marker, 'dragend', (event) => {
      //    cluster.marker.data.location.coordinates[0] = event.latLng.lng();
      //    cluster.marker.data.location.coordinates[1] = event.latLng.lat();
      //    this.cluster = cluster;
      //});


      //if (drawingMode == 'rectangle') {
      //    GMapsHelper.addListener(cluster.marker.getBounds(), 'set_at', async () => {
      //        let polygonArray = GMapsHelper.boundsToPolygon(cluster.marker.getBounds());
      //        cluster.geometry = new Polygon(polygonArray);

      //        cluster.allHomepasses = await this.getHomepasses(cluster.geometry);
      //    });

      //    GMapsHelper.addListener(cluster.marker.getBounds(), 'insert_at', async () => {
      //        let polygonArray = GMapsHelper.boundsToPolygon(cluster.marker.getBounds());
      //        cluster.geometry = new Polygon(polygonArray);

      //        cluster.allHomepasses = await this.getHomepasses(cluster.geometry);
      //    });

      //    GMapsHelper.addListener(cluster.marker.getBounds(), 'remove_at', async () => {
      //        let polygonArray = GMapsHelper.boundsToPolygon(cluster.marker.getBounds());
      //        cluster.geometry = new Polygon(polygonArray);

      //        cluster.allHomepasses = await this.getHomepasses(cluster.geometry);
      //    });
      //}
      //else {
      //    GMapsHelper.addListener(cluster.marker.getPath(), 'set_at', async () => {
      //        let polygonArray = GMapsHelper.pathArrayToPolygon(cluster.marker.getPath().getArray());
      //        cluster.geometry = new Polygon(polygonArray);

      //        cluster.allHomepasses = await this.getHomepasses(cluster.geometry);
      //    });

      //    GMapsHelper.addListener(cluster.marker.getPath(), 'insert_at', async () => {
      //        let polygonArray = GMapsHelper.pathArrayToPolygon(cluster.marker.getPath().getArray());
      //        cluster.geometry = new Polygon(polygonArray);

      //        cluster.allHomepasses = await this.getHomepasses(cluster.geometry);
      //    });

      //    GMapsHelper.addListener(cluster.marker.getPath(), 'remove_at', async () => {
      //        let polygonArray = GMapsHelper.pathArrayToPolygon(cluster.marker.getPath().getArray());
      //        cluster.geometry = new Polygon(polygonArray);

      //        cluster.allHomepasses = await this.getHomepasses(cluster.geometry);
      //    });
      //}

      GMapsHelper.addListener(cluster.marker, 'click', (event) => {
         this.cluster = cluster;
      });

   }

   stringify(obj: any): string {
      return JSON.stringify(obj);
   }

   removeUploadedCluster(index: number) {
      var cluster = this.clusters[index];

      if (cluster.marker)
         cluster.marker.setMap(null);

      this.clusters.splice(index, 1);
   }

   isAllSelected() {
      const numSelected = this.cluster.homepasses ? this.cluster.homepasses.length : 0;
      const numRows = this.cluster.allHomepasses.length;
      return numSelected === numRows;
   }

   toggleSelection(homepass: Homepass) {

      var index = -1;

      if (this.cluster.homepasses)
         index = this.cluster.homepasses.findIndex(x => x == homepass.id);
      else
         this.cluster.homepasses = [];

      if (index == -1)
         this.cluster.homepasses.push(homepass.id);
      else
         this.cluster.homepasses.splice(index, 1);
   }

   masterToggle() {

      if (this.isAllSelected()) {
         this.cluster.homepasses = [];
      }
      else {
         this.cluster.homepasses = [];
         this.cluster.allHomepasses.forEach(x => this.cluster.homepasses.push(x.id));
      }
   }

   fileChangeEvent(event: any) {

      var file = event.target.files[0];

      var reader = new FileReader();

      var fileExt = file.name.split('.').pop().toLowerCase();

      reader.onload = (e) => {

         try {

            if (fileExt == "kml") {
               let kml = reader.result as string;
               let geojson = toGeoJSON.kml((new DOMParser()).parseFromString(kml, 'text/xml'));
               this.populateClusters(geojson.features);
            }
            else if (fileExt == "zip") {
               shp(reader.result as ArrayBuffer).then((geojson) => {
                  this.populateClusters(geojson.features);
               });
            }

         } catch (e) {
            this.helper.showAlertMessage("Could not parse the file.", "error");
         }

      }

      if (fileExt == "csv" || fileExt == "kml")
         reader.readAsText(file);
      else if (fileExt == "zip")
         reader.readAsArrayBuffer(file);
      else
         this.helper.showAlertMessage("Invalid file format", "error");
   }

   populateClusters(features: any) {

      this.clusters.length = 0;

      let clusters = new Array<Cluster>();

      for (var i = 0; i < features.length; i++) {
         let properties = features[i].properties;

         let cluster = {
            name: properties.name,
            code: properties.name,
            description: "",
            geometry: features[i].geometry,
            homepasses: null,

            marker: null,
            allHomepasses: null
         };

         var polygon = GMapsHelper.createPolygon(cluster.geometry.coordinates, this.polyOptions);

         polygon.setMap(this.map);

         cluster.marker = polygon;

         clusters.push(cluster);

         this.addHomepasses(cluster);
      }

      this.clusters = clusters;
   }

   deleteCluster() {
      var index = this.clusters.findIndex(x => x.geometry.coordinates[0] == this.cluster.geometry.coordinates[0] && x.geometry.coordinates[1] == this.cluster.geometry.coordinates[1]);

      if (this.clusters[index].marker)
         this.clusters[index].marker.setMap(null);

      this.clusters.splice(index, 1);

      this.cluster = null;

      if (this.isNew == false) {
         this.clusterService.deleteCluster(this.cluster.id).subscribe(
            resp => {
               if (resp.status.toLowerCase() == "error") {
                  this.helper.showAlertMessage(resp.message, "error");
               }
               else {
                  this.helper.showAlertMessage("Cluster successfully deleted", "success");
                  this.goBack();
               }
            },
            (err) => {
               this.helper.showAlertMessage("Unable to delete cluster information.", "error");
            });
      }
   }

   save() {

      var errorMessages = this.validateCluster(this.clusters);

      if (errorMessages.length == 0) {

         this.clusters.forEach(x => { x.marker = null; x.allHomepasses = null });

         this.clusterService.saveClusters(this.clusters).subscribe(
            resp => {
               if (resp.status.toLowerCase() == "error") {
                  this.helper.showAlertMessage(resp.message, "error");
               }
               else {
                  this.helper.showAlertMessage("Cluster information saved", "success");
                  this.goBack();
               }
            },
            (err) => {
               this.helper.showAlertMessage("Unable to save cluster information.", "error");
            });
      }
      else {
         var errorMessage = this.helper.getErrorMessagesText(errorMessages);
         this.helper.showAlertMessage(errorMessage, "error");
      }
   }

   validateCluster(clusters: Cluster[]): string[] {
      var errorMessages = [];

      this.clusters.forEach(cluster => {

         if (cluster.name == null || cluster.name.trim() == '')
            errorMessages.push("Cluster Name cannot be empty");

         if (cluster.code == null || cluster.code.trim() == '')
            errorMessages.push("Cluster Code cannot be empty");
      });

      return errorMessages;
   }

   goBack(): void {
      this.location.back();
   }
}
