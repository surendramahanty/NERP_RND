import { GMapsHelper } from '../../common/geo/googleMapsHelper';
import { GeoHelper } from '../../common/geo/geoHelper';

declare var google: any;
declare var GMHelper: any;
declare var OpenLayers: any;


export class MapEntitiesHelper {

   map: any;

   constructor(map: any) {
      this.map = map;
   }

   drawPoint(entity: any, icon: any, isEditable: boolean, attachMapObject: boolean) {

      var coordinates = [];

      if (entity.geometry)
         coordinates = entity.geometry.coordinates;
      else if (entity.coordinates)
         coordinates = entity.coordinates;


      var yourLocation = new OpenLayers.Geometry.Point(coordinates[0], coordinates[1])
         .transform(new OpenLayers.Projection('EPSG:4326'), this.map.getProjectionObject());

      var iconFeature = new OpenLayers.Feature.Vector(yourLocation, { data: entity }, {
         externalGraphic: icon.url,
         pointRadius: 8,
         cursor: "pointer"
      });

      this.map.layers[1].addFeatures(iconFeature);

   }

   drawLine(entity: any, lineColor: any, strokeWeight: number, isEditable: boolean, attachMapObject: boolean) {

      let colour = "#000000";
      let lineWeight = 3;

      if (lineColor)
         colour = lineColor;

      if (strokeWeight)
         lineWeight = strokeWeight;


      var coordinates = [];

      if (entity.geometry)
         coordinates = entity.geometry.coordinates;
      else if (entity.coordinates)
         coordinates = entity.coordinates;

      var points = [];

      if (entity.geometry != undefined) {
         if (entity.geometry.coordinates.length > 1) {
            for (var i = 0; i < entity.geometry.coordinates.length; i++) {
               points.push(new OpenLayers.Geometry.Point(coordinates[i][0], coordinates[i][1])
                  .transform(new OpenLayers.Projection('EPSG:4326'), this.map.getProjectionObject())); 
            }          
         }
      }


      var iconFeature = new OpenLayers.Feature.Vector(new OpenLayers.Geometry.LineString(points), { data: entity }, {
         strokeColor: colour,
         strokeWidth: lineWeight,
         cursor: "pointer"
      });

      this.map.layers[1].addFeatures(iconFeature);      
   }

   drawPolygon(entity: any, lineColor: string, strokeWeight: number, isEditable: boolean, attachMapObject: boolean) {

      let colour = "#000000";
      let lineWeight = 3;

      if (lineColor)
         colour = lineColor;

      if (strokeWeight)
         lineWeight = strokeWeight;

      let polygon = new google.maps.Polygon({
         strokeColor: colour,
         strokeOpacity: 1.0,
         strokeWeight: lineWeight,
         editable: isEditable,
         data: entity,
         id: entity.id
      });

      let path = polygon.getPath();

      polygon.setMap(this.map);

      if (attachMapObject)
         entity['mapObject'] = polygon;

      if (entity.geometry.coordinates.length > 1) {

         for (var i = 0; i < entity.geometry.coordinates.length; i++) {
            path.push(new google.maps.LatLng(entity.geometry.coordinates[i][1], entity.geometry.coordinates[i][0]));
         }

         polygon.setEditable(false);
      }

      return polygon;
   }

   removeMapObjects(entities: any) {

      if (entities) {
         if (entities.length > 0) {
            entities.forEach(x => {
               if (x['mapObject']) {
                  x['mapObject'].setMap(null);
               }
            });
         }
         else {
            if (entities['mapObject']) {
               entities['mapObject'].setMap(null);
            }
         }
      }
   }

   //removeLines(entities: any) {

   //    if (entities) {
   //        if (entities.length > 0) {
   //            entities.forEach(x => {
   //                if (x['mapObject']) {
   //                    x['mapObject'].setMap(null);
   //                }
   //            });
   //        }
   //        else {
   //            if (entities['mapObject']) {
   //                entities['mapObject'].setMap(null);
   //            }
   //        }
   //    }
   //}

}
