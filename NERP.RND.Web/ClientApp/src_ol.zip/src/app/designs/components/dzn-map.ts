import { Component, Input, SimpleChanges, OnInit, OnChanges } from '@angular/core';
import { Design } from '../models/design';
import { AppConfig } from '../../app.config';
import { BomHelper } from '../services/bom.helper';
import { GMapsHelper } from '../../common/geo/googleMapsHelper';
import { GeoHelper } from '../../common/geo/geoHelper';
import { EntitiesHelper } from '../services/entities.helper';
import { GeoNode, Segment } from '../../common/geo/geoNode';
import { MapEntitiesHelper } from '../services/map-entities.helper';
import { GeoNodeHelper } from '../services/geoNode.helper';
import { Chamber } from '../../entities/models/chamber';
import { Position, Point, LineString } from '../../common/geo/geometry';
import { Helper } from '../../common/helper';
import { Pole } from '../../entities/models/pole';
import * as _ from "lodash";
import { Splitter } from '../../entities/models/splitter';
import { Cable } from '../../entities/models/cable';
import { SpliceClosure } from 'src/app/entities/models/spliceClosure';
import { Supplier } from 'src/app/common/models/supplier';
import { Subject } from 'rxjs';


declare var $: any;
declare var google: any;
declare var GMHelper: any;
declare var entitiesHelper: any;
declare var fromComponent: any;
declare var ria: any;
declare var OpenLayers: any;


@Component({
   selector: 'dzn-map',
   templateUrl: './dzn-map.html'
})
export class DesignMap implements OnInit, OnChanges {

   @Input() public design: Design = new Design();
   @Input() onInitializeMap: Subject<any>;

   private entityIcons = [];
   layers = [];
   map: any;
   isEntitiesGenerated: boolean = false;
   entitiesHelper: EntitiesHelper;
   mapEntitiesHelper: MapEntitiesHelper;
   selectedEntity: any;
   changedSegments = [];
   selectedLayers = ["Cable", "Chamber", "Pole", "Splitter"];

   des: any;

   constructor(
      private appConfig: AppConfig,
      private bomHelper: BomHelper) {

      this.entityIcons.push({ entityType: "Homepass", icon: { url: "/images/map-entities/homepass.png" } });
      //this.entityIcons.push({ entityType: "Chamber", icon: { url: "images/map-entities/chamber.png", anchor: new google.maps.Point(10, 10) } });
      this.entityIcons.push({ entityType: "Chamber", icon: { url: "/images/map-entities/chamber.png" } });
      this.entityIcons.push({ entityType: "ODF", icon: { url: "/images/map-entities/odf.png" } });
      this.entityIcons.push({ entityType: "Pole", icon: { url: "/images/map-entities/pole.png" } });
      this.entityIcons.push({ entityType: "Splitter", icon: { url: "/images/map-entities/splitter.png" } });
      this.entityIcons.push({ entityType: "SpliceClosure", icon: { url: "/images/map-entities/spliceclosure.png" } });

      this.layers.push({ id: "Cable", name: "Cable" });
      this.layers.push({ id: "Chamber", name: "Chamber" });
      this.layers.push({ id: "ODF", name: "ODF" });
      this.layers.push({ id: "Pole", name: "Pole" });
      this.layers.push({ id: "SpliceClosure", name: "Splice Closure" });
      this.layers.push({ id: "Splitter", name: "Splitter" });
      this.layers.push({ id: "Homepass", name: "Homepass" });

      this.isEntitiesGenerated = false;
   }

   ngOnInit() {

      this.selectedEntity = null;

      this.onInitializeMap.subscribe(event => {

         if (!this.map) {

            let location = GMapsHelper.getLatLng(this.appConfig.settings.MapCenter);

            if (this.design.bluePrint) {
               location = GMapsHelper.getLatLng(this.design.bluePrint.coordinates);
            }

            $("#tab_map").css("display", "block");

            //this.map = GMapsHelper.initializeMap('designMap', location, 18, 21);


            var mapElement = document.getElementById('designMap');


            var apiKey = "AmNbl1XqrIQVy1RWC2v4ownaDYnyt6n5lEsmTDCQLXWSTaX74eQ7652WWC6XmLL3";

            //var map = new OpenLayers.Map(mapElement, ria.ol.defaultMapOptions('EPSG:3857'));

            var road = new OpenLayers.Layer.Bing({
               key: apiKey,
               type: "Road",
               metadataParams: { mapVersion: "v1" }
            });

            var vectorLayer = new OpenLayers.Layer.Vector({
               source: new OpenLayers.Layer.Vector(),
            });

            var parentThis = this;

            this.map = new OpenLayers.Map({
               div: mapElement,
               allOverlays: true,
               layers: [road, vectorLayer],
               eventListeners: {
                  featureover: function (e) {
                     if (e.feature.data.data.geometry.type == "LineString") {
                        e.feature.style.strokeColor = "#F00";
                     }
                  },
                  featureout: function (e) {
                     if (e.feature.data.data.geometry.type == "LineString") {
                        e.feature.style.strokeColor = "#000";
                     }
                  },
                  featureclick: function (e) {
                    
                     if (e.feature.data.data.levelName == "homepasses") {
                        let homepass = parentThis.design.homepasses.find(x => x.id == e.feature.data.data.id);
                        if (homepass) {
                           parentThis.selectedEntity = homepass;
                           parentThis.selectedEntity["entityType"] = "Homepass";
                        }
                     }
                     else
                        parentThis.selectedEntity = e.feature.data.data;
                  }
               }
            });


            if (location === null || location === "")
               this.map.setCenter(new OpenLayers.LonLat(18.5245649, 73.7228783).transform('EPSG:4326', 'EPSG:3857'), 18);
            else
               this.map.setCenter(new OpenLayers.LonLat(location.lon, location.lat).transform('EPSG:4326', 'EPSG:3857'), 18);



            $("#tab_map").css("display", "");
            this.map.updateSize();


            this.mapEntitiesHelper = new MapEntitiesHelper(this.map);
            //var overlay = GMHelper.createOverlay(this.map);

            var entityItems = $('.entityMenu img');

            this.entitiesHelper = new EntitiesHelper(this.design.bookingIds, this.design.generatedCodes);
            let mapEntitiesHelper = new MapEntitiesHelper(this.map);
            this.generateMapEntities(this.design.bluePrint);

         }
      });

   }

   isEditable(value, marker) {
      if (value) {

         GMapsHelper.addListener(marker, "rightclick", (event) => {

            if (marker.draggable)
               marker.setDraggable(false);
            else
               marker.setDraggable(true);

         });

         GMapsHelper.addListener(marker, 'dragend', (event) => {
            var latLng = event.latLng;
            marker.data.geometry.coordinates = [latLng.lng(), latLng.lat()];

            //let index = this.changedSegments.findIndex(x => (x.levelId == marker.data.levelId && x.segmentId == marker.data.segmentId));

            //if (index == -1)
            //   this.changedSegments.push({ levelId: marker.data.levelId, segmentId: marker.data.segmentId });

         });
      }
   }
   ngOnChanges(changes: SimpleChanges) {

      this.selectedEntity = null;

      if (this.design.bluePrint && this.design.bluePrint.children && this.design.bluePrint.children.length > 0) {

         this.entitiesHelper = new EntitiesHelper(this.design.bookingIds, this.design.generatedCodes);

         if (this.map)
            this.generateMapEntities(this.design.bluePrint);

         this.isEntitiesGenerated = true;

         if (this.map)
            this.map.setCenter({ lat: this.design.bluePrint.coordinates[1], lng: this.design.bluePrint.coordinates[0] });
      }
      else {
         this.isEntitiesGenerated = false;
      }

      this.des = this.design.bluePrint;
   }

   isAllSelected() {
      const numSelected = this.selectedLayers ? this.selectedLayers.length : 0;
      const numRows = this.layers.length;
      return numSelected === numRows;
   }

   toggleSelection(layer: any) {

      var index = -1;

      if (this.selectedLayers)
         index = this.selectedLayers.findIndex(x => x == layer.id);
      else
         this.selectedLayers = [];

      if (index == -1)
         this.selectedLayers.push(layer.id);
      else
         this.selectedLayers.splice(index, 1);
   }

   masterToggle() {

      if (this.isAllSelected()) {
         this.selectedLayers = [];
      }
      else {
         this.selectedLayers = [];
         this.layers.forEach(x => this.selectedLayers.push(x.id));
      }
   }

   refreshLayers() {

      if (this.design.bluePrint) {

         if (this.isEntitiesGenerated == false) {
            this.generateMapEntities(this.design.bluePrint);
            this.isEntitiesGenerated = true;
            this.map.setCenter({ lat: this.design.bluePrint.coordinates[1], lng: this.design.bluePrint.coordinates[0] });
         }
      }

      this.toggleEntities(this.design.bluePrint);
   }

   refreshBlueprint() {

      $("#ajax-loading").show();

      this.entitiesHelper = new EntitiesHelper(this.design.bookingIds, this.design.generatedCodes);

      this.changedSegments.forEach(x => {

         this.refreshSegment(this.design.bluePrint, x.levelId, x.segmentId);

      });


      this.bomHelper.generateBOQ(this.design);

      $("#ajax-loading").hide();
   }

   refreshSegment(geoNode: GeoNode, levelId, segmentId) {

      if (geoNode.segments) {

         let segment = geoNode.segments.find(x => x.id == segmentId);

         if (segment) {

            if (segment.chambers && segment.chambers.length > 0) {

               segment.coordinates = segment.cable.geometry.coordinates;

               this.mapEntitiesHelper.removeMapObjects(segment.chambers);

               segment.chambers = this.entitiesHelper.createChambers(segment.chambers[0], 100, segment, 10, 10);

               this.plotPointEntities(segment.chambers, "Chamber", levelId, segmentId, true, true);
            }

            if (segment.poles && segment.poles.length > 0) {

               segment.coordinates = segment.cable.geometry.coordinates;

               this.mapEntitiesHelper.removeMapObjects(segment.poles);

               segment.poles = this.entitiesHelper.createPoles(segment.poles[0], 100, segment, 10, 10);
               this.plotPointEntities(segment.poles, "Pole", levelId, segmentId, true, true);
            }

            return false;
         }
      }

      if (geoNode.children && geoNode.children.length > 0)
         geoNode.children.forEach(g => {
            this.refreshSegment(g, g.id, segmentId);
         });
   }

   toggleEntities(group: GeoNode) {

      if (group.children) {
         group.children.forEach(x => {

            if (x.levelName == "homepasses") {
               //this.toggleEntity(x, this.selectedLayers.includes("Homepass"));
               this.setEntitiesVisible(x, this.selectedLayers.includes("Homepass"));
            }

            //if (x.level == "Feeder") {
            //    this.toggleEntity(x, this.selectedLayers.includes("Splitter"));
            //}
         });
      }

      if (group.segments)
         group.segments.forEach(x => {

            this.setEntitiesVisible(x.cable, this.selectedLayers.includes("Cable"));

            this.setEntitiesVisible(x.chambers, this.selectedLayers.includes("Chamber"));

            this.setEntitiesVisible(x.odfs, this.selectedLayers.includes("ODF"));

            this.setEntitiesVisible(x.poles, this.selectedLayers.includes("Pole"));

            this.setEntitiesVisible(x.splitters, this.selectedLayers.includes("Splitter"));

            this.setEntitiesVisible(x.spliceClosures, this.selectedLayers.includes("SpliceClosure"));

         });

      if (group.children && group.children.length > 0)
         group.children.forEach(g => {
            this.toggleEntities(g);
         });

   }

   setEntitiesVisible(entities, isVisible) {

      if (entities) {
         if (entities.length > 0) {
            entities.forEach(x => {
               if (x && x['mapObject']) {
                  x['mapObject'].setVisible(isVisible);
               }
            });
         }
         else {
            if (entities['mapObject']) {
               entities['mapObject'].setVisible(isVisible);
            }
         }
      }
   }

   generateMapEntities(group: GeoNode) {

      let levelId = group.id;

      if (group.children)
         group.children.forEach(x => {

            if (x.levelName == "homepasses") {
               //x['entityType'] = "Homepass";
               //let entityIcon = this.entityIcons.find(i => i.entityType == 'Homepass');
               //this.drawPoint(x, entityIcon.icon, false);

               this.plotPointEntities(x, "Homepass", levelId, x.id, true, true);
            }
            //else {
            //    x['entityType'] = "Splitter";
            //    let entityIcon = this.entityIcons.find(i => i.entityType == 'Splitter');
            //    this.drawPoint(x, entityIcon.icon, true);
            //}
         });

      if (group.segments)
         group.segments.forEach(x => {

            this.plotLineEntities(x.cable, "Cable", levelId, x.id, true, true);

            this.plotPointEntities(x.chambers, "Chamber", levelId, x.id, true, true);

            this.plotPointEntities(x.odfs, "ODF", levelId, x.id, true, true);

            this.plotPointEntities(x.poles, "Pole", levelId, x.id, true, true);

            this.plotPointEntities(x.splitters, "Splitter", levelId, x.id, true, true);

            this.plotPointEntities(x.spliceClosures, "SpliceClosure", levelId, x.id, true, true);

         });

      if (group.children && group.children.length > 0)
         group.children.forEach(g => {
            this.generateMapEntities(g);
         });

   }

   plotPointEntities(entities: any, entityType: string, levelId: string, segmentId: string, isEditable: boolean, attachMapObject: boolean) {

      let entityIcon = this.entityIcons.find(i => i.entityType == entityType);

      if (entities) {

         if (entities.length > 0) {
            entities.forEach(x => {
               this.plotPointEntity(x, entityIcon.icon, levelId, segmentId, isEditable, attachMapObject);
            });
         }
         else {
            this.plotPointEntity(entities, entityIcon.icon, levelId, segmentId, isEditable, attachMapObject);
         }
      }
   }

   plotPointEntity(entity: any, entityIcon: any, levelId: string, segmentId: string, isEditable: boolean, attachMapObject: boolean) {

      if (entity) {

         entity["levelId"] = levelId;
         entity["segmentId"] = segmentId;

         let marker = this.mapEntitiesHelper.drawPoint(entity, entityIcon, isEditable, attachMapObject);

         //this.map.on("click", function (e) {
         //   this.map.forEachFeatureAtPixel(e.pixel, function (feature, layer) {
         //      //do something
         //      console.log(feature);
         //      console.log(layer);
         //   })
         //});

         //GMapsHelper.addListener(marker, 'click', (event) => {
         //   if (marker.data.levelName == "homepasses") {
         //      let homepass = this.design.homepasses.find(x => x.id == marker.data.id);
         //      if (homepass) {
         //         this.selectedEntity = homepass;
         //         this.selectedEntity["entityType"] = "Homepass";
         //      }
         //   }
         //   else
         //      this.selectedEntity = marker.data;
         //});

         //if (isEditable) {

         //   GMapsHelper.addListener(marker, "rightclick", (event) => {

         //      if (marker.draggable)
         //         marker.setDraggable(false);
         //      else
         //         marker.setDraggable(true);

         //   });

         //   GMapsHelper.addListener(marker, 'dragend', (event) => {
         //      var latLng = event.latLng;
         //      marker.data.geometry.coordinates = [latLng.lng(), latLng.lat()];

         //      //let index = this.changedSegments.findIndex(x => (x.levelId == marker.data.levelId && x.segmentId == marker.data.segmentId));

         //      //if (index == -1)
         //      //   this.changedSegments.push({ levelId: marker.data.levelId, segmentId: marker.data.segmentId });

         //   });
         //}
      }
   }

   plotLineEntities(entities: any, entityType: string, levelId: string, segmentId: string, isEditable: boolean, attachMapObject: boolean) {

      if (entities) {
         if (entities.length > 0) {
            entities.forEach(x => {
               this.plotLineEntity(x, levelId, segmentId, isEditable, attachMapObject);
            });
         }
         else {
            this.plotLineEntity(entities, levelId, segmentId, isEditable, attachMapObject);
         }
      }
   }

   plotLineEntity(entity: any, levelId: string, segmentId: string, isEditable: boolean, attachMapObject: boolean) {

      if (entity) {

         entity["levelId"] = levelId;
         entity["segmentId"] = segmentId;

         let polyLine = this.mapEntitiesHelper.drawLine(entity, "#000", 2, isEditable, attachMapObject);

         //GMapsHelper.addListener(polyLine, 'click', (event) => {
         //   this.selectedEntity = polyLine.data;
         //});

         //if (isEditable) {

         //   GMapsHelper.addListener(polyLine, "rightclick", (event) => {

         //      if (polyLine.editable)
         //         polyLine.setEditable(false);
         //      else
         //         polyLine.setEditable(true);
         //   });

         //   GMapsHelper.addListener(polyLine.getPath(), 'set_at', () => {

         //      var coords = polyLine.getPath().getArray();

         //      let newCoords = new Array<number[]>();

         //      coords.forEach(x => {
         //         newCoords.push([x.lng(), x.lat()]);
         //      });


         //      polyLine.data.geometry.coordinates = GeoHelper.cleanLineCoordinates(newCoords);

         //      polyLine.data.measuredLength = GeoHelper.getLength(polyLine.data.geometry.coordinates);

         //      let index = this.changedSegments.findIndex(x => (x.levelId == polyLine.data.levelId && x.segmentId == polyLine.data.segmentId));

         //      if (index == -1)
         //         this.changedSegments.push({ levelId: polyLine.data.levelId, segmentId: polyLine.data.segmentId });

         //   });
         //}
      }
   }

   deleteEntity() {

      this.mapEntitiesHelper.removeMapObjects(this.selectedEntity);
      GeoNodeHelper.deleteSegmentEntity(this.design.bluePrint, this.selectedEntity.id, this.selectedEntity.entityType);
      this.selectedEntity = null;

      this.refreshBlueprint();
   }

   stringify(object: any) {
      return JSON.stringify(object);
   }
}
